import Img1 from "../assets/best_selling1.jpg.webp"
import Img2 from "../assets/best_selling2.jpg.webp"
import Img3 from "../assets/best_selling3.jpg.webp"
import Img4 from "../assets/best_selling4.jpg.webp"
import Img5 from "../assets/best_selling5.jpg.webp"
import Img6 from "../assets/best_selling6.jpg.webp"


export const data = [
    {
        img: Img1 ,
        title: 'Moon dance',
        author: 'J. R rain',
    },
    {
        img: Img2,
        title: 'Moon dance',
        author: 'J. R rain',
    },
    {
        img: Img3,
        title: 'Moon dance',
        author: 'J. R rain',
    },
    {
        img: Img4,
        title: 'Moon dance',
        author: 'J. R rain',
    },
    {
        img: Img5 ,
        title: 'Moon dance',
        author: 'J. R rain',
    },
    {
        img: Img6,
        title: 'Moon dance',
        author: 'J. R rain',
    },
] 