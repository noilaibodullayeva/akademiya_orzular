import Img1 from "../assets/ingliz.JPG"
import Img2 from "../assets/inglizn.JPG"
import Img3 from "../assets/jahonakamatem.JPG"
import Img4 from "../assets/koreys.JPG"
import Img5 from "../assets/matem.JPG"
import Img6 from "../assets/mental.JPG"
import Img7 from "../assets/rus.JPG"
import Img8 from "../assets/ezozingliz.JPG"


export const Coursesdata = [
    {
        img: Img1 ,
        title: 'Sitora Shavkatova',
        author: 'Dush/Chor/Ju 9:00 kids',
        second: 'Se/Pay/Shan 9:00 0guruh',
    },
    {
        img: Img2,
        title: 'Noila Ibodullayeva',
        author: 'Dush/Chor/Ju 9:00 PMT',
        second: 'Se/Pay/Shan 9:00 CEFR/IELTS',
        third: 'Se/Pay/Shan 14:30 CEFR/IELTS'
    },
    {
        img: Img3,
        title: 'Jahongir Ibrohimov',
        author: 'Se/Pay/Shan 8:30 PMT',
    },
    {
        img: Img4,
        title: 'Asilmurod Islamov',
        author: 'Se/Pay/Shan 16:00',
    },
    {
        img: Img5 ,
        title: 'Laylo Akaboyeva',
        author: 'Se/Pay/Shan 16:00',
    },
    {
        img: Img6,
        title: 'Laylo Akaboyeva',
        author: 'Se/Pay/Shan 16:00',
    },
    {
        img: Img7 ,
        title: 'Sitora Shavkatova',
        author: 'Dush/Chor/Ju 8:30 kids',
    },
    {
        img: Img8 ,
        title: ' E`zoza Muqimova',
        author: 'Dush/Chor/Ju 14:00 kids',
    },
] 