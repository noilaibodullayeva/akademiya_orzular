import Img1 from "../assets/noilaimg.jpg"
import Img2 from "../assets/ezoza.jpg"
import Img3 from "../assets/jahon aka.jpg"
import Img4 from "../assets/sitora.jpg"
import Img5 from "../assets/asil.PNG"
import Img6 from "../assets/laylo.jpg"



export const Indexdata = [
    {
        img: Img1 ,
        name: 'Noila Ibodullayeva',
        position: 'The CEO and English Teacher',
        experience: '1.5 yil +'
    },
    {
        img: Img2 ,
        name: "E'zoza Muqimova",
        position: 'Kids Ingliz tili ustozi',
        experience: '1 yil +'
    },
    {
        img: Img3 ,
        name: 'Jahongir Ibrohimov',
        position: 'Matematika o`qituvchisi',
        experience: '8 yil +'
    },
    {
        img: Img5 ,
        name: "Asilmurod Islamov",
        position: 'Koreys tili ustozi',
        experience: '1.5 year+'
    },
    {
        img: Img6 ,
        name: "Laylo Akaboyeva",
        position: 'Matematika va mental arifmetika ustozi',
        experience: '1.5 year+',
    },
    {
        img: Img4 ,
        name: "Sitora Shavkatova",
        position: 'Ingliz tili va mental arifmetika ustozi',
        experience: '1.5 year+',
    },
] 