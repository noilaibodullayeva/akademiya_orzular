import './App.css';
import BestSelling from './components/BestSelling';
import Week from './components/Week';

function App() {
  return (
    <div className="App">
      <BestSelling/>
      <Week/>
    </div>
  );
}

export default App;
