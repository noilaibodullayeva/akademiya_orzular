import Img1 from "../assets/best_selling1.jpg.webp"

export const data = [
    {
        img: Img1 ,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1 ,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
    {
        img: Img1,
        title: 'moon dance',
        author: 'J. R rain',
    },
] 