import Img1 from "../assets/best_selling1.jpg.webp"

export const Indexdata = [
    {
        img: Img1 ,
        title: 'The range Of dragons',
        author: 'By evcan winter',
        price:'$50.00'
    },
    {
        img: Img1 ,
        title: 'The range Of dragons',
        author: 'By evcan winter',
        price:'$50.00'
    },
    {
        img: Img1 ,
        title: 'The range Of dragons',
        author: 'By evcan winter',
        price:'$50.00'
    },
    {
        img: Img1 ,
        title: 'The range Of dragons',
        author: 'By evcan winter',
        price:'$50.00'
    },
] 